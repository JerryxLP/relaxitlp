EMOJIS = {"check": "☑"}

LEAVE_NOW_CALL = "LEAVE"
PASS_CALL = "PASS"
GENDER_CALLS = {"MALE_CALL": "ml", "FEMALE_CALL": "fml"}
CITY_CALLS = {"MOSCOW": "Москва", "SPB": "Санкт-Петербург", "KAZAN": "Казань",
              "NIZH": "Нижний Новгород"}

STATUS = {"PROFILE": 1, "FREE": 2}
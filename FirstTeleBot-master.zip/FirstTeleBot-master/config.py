TOKEN = "classified"
PROXI = "https://telegg.ru/orig/bot"

DB = "data/users.db"
